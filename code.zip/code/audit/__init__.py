"""Evidence-grounded deletion auditing."""

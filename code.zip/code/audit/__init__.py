"""Evidence-grounded deletion auditing."""
